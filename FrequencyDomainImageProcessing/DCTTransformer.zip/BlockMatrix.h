#pragma once
#include <memory>
#include <vector>

#define BLOCK_SIZE 8

class Block
{
private:
	int height = BLOCK_SIZE;
	int width = BLOCK_SIZE;

	double* dct_res;
public:
	double& operator()(int y, int x)
	{
		return dct_res[y * width + x];
	}

	Block()
	{
		dct_res = new double[BLOCK_SIZE* BLOCK_SIZE];
	}

	~Block()
	{
		delete[] dct_res;
	}
};

class BlockMatrix
{
private:
	int rows=0;
	int cols=0;

	std::vector<std::vector<std::shared_ptr<Block>>> res;
public:
	int row()
	{
		return rows;
	}

	int col()
	{
		return cols;
	}

	Block& operator()(int y, int x)
	{
		if (y >= 0 && y < rows && x >= 0 && x < cols)
		{
			if (res[y][x] == nullptr)
				res[y][x] = std::make_shared<Block>();
			return *res[y][x].get();
		}
		else
			std::exit(EXIT_FAILURE);
	}

	void Resize(int rows, int cols)
	{
		this->rows = rows;
		this->cols = cols;

		res.resize(rows);
		for (int i = 0; i < rows; i++)
			res[i].resize(cols);
	}
};